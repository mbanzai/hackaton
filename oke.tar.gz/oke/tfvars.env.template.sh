# Terraform mauro-prod
export TF_VAR_tenancy_ocid=ocid1.tenancy.oc1..aaaaaaaapga7yqirmwlfq2r6cyqcwyqtxaynswws3uz4iwj2kwxl7mfonp5a
export TF_VAR_user_ocid=ocid1.user.oc1..aaaaaaaa2jmri5xtdfjr3mm4jdyeuzh76cse7mx6if4ye4ywibo55cqpci6q
export TF_VAR_fingerprint=eb:53:c3:74:a6:91:03:1c:64:7e:f5:19:27:31:e5:37
export TF_VAR_region=uk-london-1
export TF_VAR_private_key_path=/Users/mcossu/.oci/oci_api_key.pem
export TF_VAR_compartment_ocid=ocid1.compartment.oc1..aaaaaaaahr3sgpoergtftsiqnrlincpd62d7ghj7p2fghyyom2q53n4nnp7q
